(function() {
var exports = {};
exports.id = 922;
exports.ids = [922];
exports.modules = {

/***/ 7360:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": function() { return /* binding */ Post; },
  "getStaticPaths": function() { return /* binding */ getStaticPaths; },
  "getStaticProps": function() { return /* binding */ getStaticProps; }
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(5282);
;// CONCATENATED MODULE: external "next/router"
var router_namespaceObject = require("next/router");;
// EXTERNAL MODULE: external "next/head"
var head_ = __webpack_require__(701);
var head_default = /*#__PURE__*/__webpack_require__.n(head_);
;// CONCATENATED MODULE: external "next/error"
var error_namespaceObject = require("next/error");;
var error_default = /*#__PURE__*/__webpack_require__.n(error_namespaceObject);
// EXTERNAL MODULE: ./components/container.js
var container = __webpack_require__(6742);
;// CONCATENATED MODULE: external "@contentful/rich-text-react-renderer"
var rich_text_react_renderer_namespaceObject = require("@contentful/rich-text-react-renderer");;
// EXTERNAL MODULE: ./components/markdown-styles.module.css
var markdown_styles_module = __webpack_require__(948);
var markdown_styles_module_default = /*#__PURE__*/__webpack_require__.n(markdown_styles_module);
;// CONCATENATED MODULE: ./components/post-body.js



function PostBody({
  content
}) {
  return /*#__PURE__*/jsx_runtime_.jsx("div", {
    className: "max-w-2xl mx-auto",
    children: /*#__PURE__*/jsx_runtime_.jsx("div", {
      className: (markdown_styles_module_default()).markdown,
      children: (0,rich_text_react_renderer_namespaceObject.documentToReactComponents)(content.json)
    })
  });
}
// EXTERNAL MODULE: ./components/more-stories.js + 1 modules
var more_stories = __webpack_require__(7929);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
;// CONCATENATED MODULE: ./components/header.js



function Header() {
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)("h2", {
    className: "text-2xl md:text-4xl font-bold tracking-tight md:tracking-tighter leading-tight mb-20 mt-8",
    children: [/*#__PURE__*/jsx_runtime_.jsx(next_link.default, {
      href: "/",
      children: /*#__PURE__*/jsx_runtime_.jsx("a", {
        className: "hover:underline",
        children: "Blog"
      })
    }), "."]
  });
}
// EXTERNAL MODULE: ./components/avatar.js
var avatar = __webpack_require__(6838);
// EXTERNAL MODULE: ./components/date.js
var components_date = __webpack_require__(1297);
// EXTERNAL MODULE: ./components/cover-image.js
var cover_image = __webpack_require__(3763);
;// CONCATENATED MODULE: ./components/post-title.js

function PostTitle({
  children
}) {
  return /*#__PURE__*/jsx_runtime_.jsx("h1", {
    className: "text-6xl md:text-7xl lg:text-8xl font-bold tracking-tighter leading-tight md:leading-none mb-12 text-center md:text-left",
    children: children
  });
}
;// CONCATENATED MODULE: ./components/post-header.js







function PostHeader({
  title,
  coverImage,
  date,
  author
}) {
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
    children: [/*#__PURE__*/jsx_runtime_.jsx(PostTitle, {
      children: title
    }), /*#__PURE__*/jsx_runtime_.jsx("div", {
      className: "hidden md:block md:mb-12",
      children: author && /*#__PURE__*/jsx_runtime_.jsx(avatar/* default */.Z, {
        name: author.name,
        picture: author.picture
      })
    }), /*#__PURE__*/jsx_runtime_.jsx("div", {
      className: "mb-8 md:mb-16 sm:mx-0",
      children: /*#__PURE__*/jsx_runtime_.jsx(cover_image/* default */.Z, {
        title: title,
        url: coverImage.url
      })
    }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
      className: "max-w-2xl mx-auto",
      children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
        className: "block md:hidden mb-6",
        children: author && /*#__PURE__*/jsx_runtime_.jsx(avatar/* default */.Z, {
          name: author.name,
          picture: author.picture
        })
      }), /*#__PURE__*/jsx_runtime_.jsx("div", {
        className: "mb-6 text-lg",
        children: /*#__PURE__*/jsx_runtime_.jsx(components_date/* default */.Z, {
          dateString: date
        })
      })]
    })]
  });
}
;// CONCATENATED MODULE: ./components/section-separator.js

function SectionSeparator() {
  return /*#__PURE__*/jsx_runtime_.jsx("hr", {
    className: "border-accent-2 mt-28 mb-24"
  });
}
// EXTERNAL MODULE: ./components/layout.js + 3 modules
var layout = __webpack_require__(5095);
// EXTERNAL MODULE: ./lib/api.js
var api = __webpack_require__(883);
// EXTERNAL MODULE: ./lib/constants.js
var constants = __webpack_require__(8098);
;// CONCATENATED MODULE: ./pages/posts/[slug].js
















function Post({
  post,
  morePosts,
  preview
}) {
  const router = (0,router_namespaceObject.useRouter)();

  if (!router.isFallback && !post) {
    return /*#__PURE__*/jsx_runtime_.jsx((error_default()), {
      statusCode: 404
    });
  }

  return /*#__PURE__*/jsx_runtime_.jsx(layout/* default */.Z, {
    preview: preview,
    children: /*#__PURE__*/(0,jsx_runtime_.jsxs)(container/* default */.Z, {
      children: [/*#__PURE__*/jsx_runtime_.jsx(Header, {}), router.isFallback ? /*#__PURE__*/jsx_runtime_.jsx(PostTitle, {
        children: "Loading\u2026"
      }) : /*#__PURE__*/(0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("article", {
          children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)((head_default()), {
            children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("title", {
              children: [post.title, " | Next.js Blog Example with ", constants/* CMS_NAME */.yf]
            }), /*#__PURE__*/jsx_runtime_.jsx("meta", {
              property: "og:image",
              content: post.coverImage.url
            })]
          }), /*#__PURE__*/jsx_runtime_.jsx(PostHeader, {
            title: post.title,
            coverImage: post.coverImage,
            date: post.date,
            author: post.author
          }), /*#__PURE__*/jsx_runtime_.jsx(PostBody, {
            content: post.content
          })]
        }), /*#__PURE__*/jsx_runtime_.jsx(SectionSeparator, {}), morePosts && morePosts.length > 0 && /*#__PURE__*/jsx_runtime_.jsx(more_stories/* default */.Z, {
          posts: morePosts
        })]
      })]
    })
  });
}
async function getStaticProps({
  params,
  preview = false
}) {
  var _data$post, _data$morePosts;

  const data = await (0,api/* getPostAndMorePosts */.ds)(params.slug, preview);
  return {
    props: {
      preview,
      post: (_data$post = data === null || data === void 0 ? void 0 : data.post) !== null && _data$post !== void 0 ? _data$post : null,
      morePosts: (_data$morePosts = data === null || data === void 0 ? void 0 : data.morePosts) !== null && _data$morePosts !== void 0 ? _data$morePosts : null
    }
  };
}
async function getStaticPaths() {
  var _allPosts$map;

  const allPosts = await (0,api/* getAllPostsWithSlug */.h9)();
  return {
    paths: (_allPosts$map = allPosts === null || allPosts === void 0 ? void 0 : allPosts.map(({
      slug
    }) => `/posts/${slug}`)) !== null && _allPosts$map !== void 0 ? _allPosts$map : [],
    fallback: true
  };
}

/***/ }),

/***/ 948:
/***/ (function(module) {

// Exports
module.exports = {
	"markdown": "markdown-styles_markdown__1x9gM"
};


/***/ }),

/***/ 4058:
/***/ (function(module) {

"use strict";
module.exports = require("classnames");;

/***/ }),

/***/ 3879:
/***/ (function(module) {

"use strict";
module.exports = require("date-fns");;

/***/ }),

/***/ 8417:
/***/ (function(module) {

"use strict";
module.exports = require("next/dist/next-server/lib/router-context.js");;

/***/ }),

/***/ 2238:
/***/ (function(module) {

"use strict";
module.exports = require("next/dist/next-server/lib/router/utils/get-asset-path-from-route.js");;

/***/ }),

/***/ 701:
/***/ (function(module) {

"use strict";
module.exports = require("next/head");;

/***/ }),

/***/ 9297:
/***/ (function(module) {

"use strict";
module.exports = require("react");;

/***/ }),

/***/ 5282:
/***/ (function(module) {

"use strict";
module.exports = require("react/jsx-runtime");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = function(moduleId) { return __webpack_require__(__webpack_require__.s = moduleId); }
var __webpack_exports__ = __webpack_require__.X(0, [664,883,298], function() { return __webpack_exec__(7360); });
module.exports = __webpack_exports__;

})();