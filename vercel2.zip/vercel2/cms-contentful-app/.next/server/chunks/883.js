exports.id = 883;
exports.ids = [883];
exports.modules = {

/***/ 883:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "iy": function() { return /* binding */ getPreviewPostBySlug; },
/* harmony export */   "h9": function() { return /* binding */ getAllPostsWithSlug; },
/* harmony export */   "DT": function() { return /* binding */ getAllPostsForHome; },
/* harmony export */   "ds": function() { return /* binding */ getPostAndMorePosts; }
/* harmony export */ });
const POST_GRAPHQL_FIELDS = `
slug
title
coverImage {
  url
}
date
excerpt
content {
  json
}
`;

async function fetchGraphQL(query, preview = false) {
  return fetch(`https://graphql.contentful.com/content/v1/spaces/${process.env.CONTENTFUL_SPACE_ID}`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${preview ? process.env.CONTENTFUL_PREVIEW_ACCESS_TOKEN : process.env.CONTENTFUL_ACCESS_TOKEN}`
    },
    body: JSON.stringify({
      query
    })
  }).then(response => response.json());
}

function extractPost(fetchResponse) {
  var _fetchResponse$data, _fetchResponse$data$p, _fetchResponse$data$p2;

  return fetchResponse === null || fetchResponse === void 0 ? void 0 : (_fetchResponse$data = fetchResponse.data) === null || _fetchResponse$data === void 0 ? void 0 : (_fetchResponse$data$p = _fetchResponse$data.postCollection) === null || _fetchResponse$data$p === void 0 ? void 0 : (_fetchResponse$data$p2 = _fetchResponse$data$p.items) === null || _fetchResponse$data$p2 === void 0 ? void 0 : _fetchResponse$data$p2[0];
}

function extractPostEntries(fetchResponse) {
  var _fetchResponse$data2, _fetchResponse$data2$;

  return fetchResponse === null || fetchResponse === void 0 ? void 0 : (_fetchResponse$data2 = fetchResponse.data) === null || _fetchResponse$data2 === void 0 ? void 0 : (_fetchResponse$data2$ = _fetchResponse$data2.postCollection) === null || _fetchResponse$data2$ === void 0 ? void 0 : _fetchResponse$data2$.items;
}

async function getPreviewPostBySlug(slug) {
  const entry = await fetchGraphQL(`query {
      postCollection(where: { slug: "${slug}" }, preview: true, limit: 1) {
        items {
          ${POST_GRAPHQL_FIELDS}
        }
      }
    }`, true);
  return extractPost(entry);
}
async function getAllPostsWithSlug() {
  const entries = await fetchGraphQL(`query {
      postCollection(where: { slug_exists: true }, order: date_DESC) {
        items {
          ${POST_GRAPHQL_FIELDS}
        }
      }
    }`);
  return extractPostEntries(entries);
}
async function getAllPostsForHome(preview) {
  const entries = await fetchGraphQL(`query {
      postCollection(order: date_DESC, preview: ${preview ? 'true' : 'false'}) {
        items {
          ${POST_GRAPHQL_FIELDS}
        }
      }
    }`, preview);
  return extractPostEntries(entries);
}
async function getPostAndMorePosts(slug, preview) {
  const entry = await fetchGraphQL(`query {
      postCollection(where: { slug: "${slug}" }, preview: ${preview ? 'true' : 'false'}, limit: 1) {
        items {
          ${POST_GRAPHQL_FIELDS}
        }
      }
    }`, preview);
  const entries = await fetchGraphQL(`query {
      postCollection(where: { slug_not_in: "${slug}" }, order: date_DESC, preview: ${preview ? 'true' : 'false'}, limit: 2) {
        items {
          ${POST_GRAPHQL_FIELDS}
        }
      }
    }`, preview);
  return {
    post: extractPost(entry),
    morePosts: extractPostEntries(entries)
  };
}

/***/ })

};
;